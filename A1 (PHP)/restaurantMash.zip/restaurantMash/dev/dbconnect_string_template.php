<?php
        $g_dbconnect_string="host=DB_HOSTNAME port=5432 dbname=DB_NAME user=DB_USER password=DB_PASSWORD";
?>
