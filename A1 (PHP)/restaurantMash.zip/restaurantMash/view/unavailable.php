<?php
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<link rel="stylesheet" type="text/css" href="style.css" />
		<title>RestaurantMash</title>
	</head>
	<body>
		<header><center><h1>RestaurantMash</h1></center></header>
		<nav>
			<ul>
				<li> <a href="?operation=compete">Compete</a>
				<li> <a href="?operation=results">Results</a>
				<li> <a href="?operation=logout">Logout</a>
			</ul>
		</nav>
		<main>
			<h3>The User doesn't exist!</h3>
		</main>
		<footer>
		</footer>
	</body>
</html>

