<?php
        $g_dbconnect_string="host=mcsdb.utm.utoronto.ca port=5432 dbname=guptaak2_309 user=guptaak2 password=08193";
?>
